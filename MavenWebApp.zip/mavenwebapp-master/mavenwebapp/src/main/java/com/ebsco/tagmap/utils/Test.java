package com.ebsco.tagmap.utils;

public class Test {
	public String go() {
		return "Hi There";
	}
}
